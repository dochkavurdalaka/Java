package com.example.server;

import com.google.gson.Gson;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {

    static final int COUNT_GAMERS = 2;

    @Override
    public void start(Stage stage) throws IOException {



        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));

        Pane root = (Pane)fxmlLoader.load();

        Rectangle rectangle = (Rectangle) root.getChildren().get(7);
        double height = rectangle.getHeight();
        double width = rectangle.getWidth();
        for(int i = 0; i<COUNT_GAMERS; i++){
            Line arrow = new Line(rectangle.getWidth(), (i + 0.5) * height / COUNT_GAMERS, rectangle.getWidth() + 76.5, (i + 0.5) * height / COUNT_GAMERS);

            arrow.setId("arrow" + i);
            root.getChildren().add(arrow);

            Polygon polygon = new Polygon();
            polygon.getPoints().addAll(new Double[]{
                    10.0, (i + 0.5) * height / COUNT_GAMERS - 20,
                    width-10, (i + 0.5) * height / COUNT_GAMERS,
                    10.0, (i + 0.5) * height / COUNT_GAMERS + 20 });
            polygon.setFill(Color.BLUE);
            polygon.setId("polygon" + i);
            root.getChildren().add(polygon);
        }




        Scene scene = new Scene(root);


        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }





    public static void main(String[] args) {
        launch();



    }
}