open module com.example.server {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.sql;
    requires java.persistence;
    requires org.hibernate.orm.core;
    requires java.naming;

    //opens com.example.server to javafx.fxml, com.google.gson, java.sql;
    exports com.example.server;
}