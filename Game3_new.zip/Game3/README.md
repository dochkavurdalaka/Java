# JavaGame
Simple Java multiplayer game created with use of JavaFX
