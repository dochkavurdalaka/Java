package com.example.server;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.Objects;

public class AuthenticationController {
    static Object lock = null;

    static String answer = "";

    static boolean result = false;

    @FXML
    public TextField input_login;

    @FXML
    public Label text;

    @FXML
    public void onEnterButtonClick() throws InterruptedException {
        answer = input_login.getText();
        if (Objects.equals(answer, "")){
            text.setText("input field is empty!");
            return;
        }
        synchronized (lock){
            lock.notifyAll();
        }
        synchronized (lock){
            lock.wait();
        }
        if(result == false){
            ((Stage) input_login.getScene().getWindow()).close();
        }
        else{
            text.setText("This nickname already exists!");
        }
    }
}
