package com.example.server;

import com.google.gson.Gson;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;


import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Objects;

import static java.lang.Math.*;

public class MulThrGameServer {
    static final int COUNT_GAMERS = 2;

    InformationGamers info;

    String[] nicknames;

    Thread movingCircles;

    Thread[] sendandreceive;
    Thread[] auth;

    boolean threadPause = false;

    boolean gameContinuing = true;

    List<Gamers> list;

    protected void MainWork() {

        if (movingCircles != null) return;

        class CirclesMove implements Runnable {
            MulThrGameServer hc;

            public CirclesMove(MulThrGameServer hc) {
                this.hc = hc;
            }

            boolean CheckCircleArrow(InformationGamers.Circle circle, InformationGamers.Line arrow) {
                double x = arrow.x_end;
                double y = arrow.y_end;
                double x_0 = circle.x;
                double y_0 = circle.y;
                double R = circle.R;
                return !((x - x_0) * (x - x_0) + (y - y_0) * (y - y_0) <= R * R);
            }
            @Override
            public void run() {
                InformationGamers.Line line = info.line;
                double min = min(line.y_end, line.y_start);
                double max = max(line.y_end, line.y_start);

                max = max - min;
                min = 0;

                double length = abs(info.border.x_end);

                double yB = info.circleBig.y;
                double yS = info.circleSmall.y;

                int signB = 1;
                int signS = -1;


                InformationGamers.Line[] arrows = info.arrows;
                InformationGamers.Rectangle rectangle = info.rectangle;

                for (int i = 0; i < COUNT_GAMERS; i++) {
                    arrows[i].x_start = rectangle.width;
                    arrows[i].x_end = rectangle.width + 76;
                }


                InformationGamers.Circle circleBig = info.circleBig;
                InformationGamers.Circle circleSmall = info.circleSmall;

                boolean isRun = true;
                while (isRun) {

                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }


                    if (threadPause == true) {
                        synchronized (hc) {
                            try {
                                hc.wait();
                                threadPause = false;
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }

                    }

                    yB += signB * 2;

                    if (yB > max - circleBig.R || yB < min + circleBig.R) {
                        signB = -signB;
                    }
                    yS += signS * 4;
                    if (yS > max - circleSmall.R || yS < min + circleSmall.R) {
                        signS = -signS;
                    }
                    circleBig.y = yB;
                    circleSmall.y = yS;


                    for (int i = 0; i < COUNT_GAMERS; i++) {
                        if (info.arrow_shots[i] == true) {
                            InformationGamers.Line arrow = arrows[i];

                            arrow.x_end += 6;
                            arrow.x_start += 6;

                            if (arrow.x_end >= length) {
                                info.arrow_shots[i] = false;
                                arrow.x_end = rectangle.width + 76;
                                arrow.x_start = rectangle.width;


                            } else if (!CheckCircleArrow(circleBig, arrow)) {
                                info.arrow_shots[i] = false;
                                arrow.x_end = rectangle.width + 76;
                                arrow.x_start = rectangle.width;
                                info.hit_counts[i] += 1;


                            } else if (!CheckCircleArrow(circleSmall, arrow)) {
                                info.arrow_shots[i] = false;
                                arrow.x_end = rectangle.width + 76;
                                arrow.x_start = rectangle.width;
                                info.hit_counts[i] += 2;
                            }

                        }
                    }

                    for (int i = 0; i < COUNT_GAMERS; i++) {
                        if (info.hit_counts[i] >= 3) {
                            isRun = false;
                            gameContinuing = false;
                            System.out.println("The winner is " + nicknames[i] + " !!!");
                            System.out.println("Awards !!!");
                            movingCircles = null;

                            Session session = HibernateSessionFactoryUtil.getSessionFactory().openSession();

                            Query query = session.createQuery("from Gamers where name = :name");
                            query.setParameter("name", nicknames[i]);
                            List<Gamers> list = (List<Gamers>) query.list();

                            Transaction tx1 = session.beginTransaction();
                            Gamers g;
                            if (list.isEmpty()) {
                                g = new Gamers();
                                g.setName(nicknames[i]);
                                g.setCount(1);
                                session.save(g);
                            } else {
                                g = list.get(0);
                                g.setCount(g.getCount() + 1);
                                session.update(g);
                            }
                            tx1.commit();
                            session.close();
                        }
                    }
                }
            }
        }
        movingCircles = new Thread(new CirclesMove(this));
        movingCircles.start();
    }

    protected void Auth(Socket cs, int thread_num){
        class Authentication implements Runnable {
            MulThrGameServer hc;
            Socket cs;
            int thread_num;


            public Authentication(MulThrGameServer hc, Socket cs, int thread_num) {
                this.hc = hc;
                this.cs = cs;
                this.thread_num = thread_num;
            }


            @Override
            public void run() {

                Gson gson = new Gson();
                BufferedReader dis = null;
                BufferedWriter dos = null;

                try {
                    dis = new BufferedReader(new InputStreamReader(cs.getInputStream()));
                    dos = new BufferedWriter(new OutputStreamWriter(cs.getOutputStream()));

                    dos.write(thread_num + "\n"); // отправляем сообщение на клиент
                    dos.flush();

                    if (thread_num == 0) {
                        String info_str = dis.readLine();
                        info = gson.fromJson(info_str, InformationGamers.class);
                    }
                    dos.write(gson.toJson(list) + "\n");
                    dos.flush();

                    boolean flag = true;
                    while(flag == true) {
                        synchronized (hc) {
                            String nickname = dis.readLine();
                            flag = false;
                            for (int i = 0; i < COUNT_GAMERS; i++) {
                                if (Objects.equals(nicknames[i], nickname)) {
                                    flag = true;
                                }
                            }
                            dos.write(gson.toJson(flag) + "\n");
                            dos.flush();
                            nicknames[thread_num] = nickname;
                        }
                    }


                    System.out.println(nicknames[thread_num]);

                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        auth[thread_num] = new Thread(new Authentication(this, cs, thread_num));
        auth[thread_num].start();
    }


    int port = 3124;
    InetAddress ip = null;
    ServerSocket ss;


    protected void send_and_receive(Socket cs, int thread_num) {

        class SendReceive implements Runnable {
            MulThrGameServer hc;
            Socket cs;
            int thread_num;

            final Object lock = new Object();
            final Object lock2 = new Object();

            public SendReceive(MulThrGameServer hc, Socket cs, int thread_num) {
                this.hc = hc;
                this.cs = cs;
                this.thread_num = thread_num;
            }


            @Override
            public void run() {

                Gson gson = new Gson();
                BufferedReader dis = null;
                BufferedWriter dos = null;

                try {
                    dis = new BufferedReader(new InputStreamReader(cs.getInputStream()));
                    dos = new BufferedWriter(new OutputStreamWriter(cs.getOutputStream()));


                    while (true) {
                        Thread.sleep(30);
                        String info_json = gson.toJson(info);

                        if (gameContinuing == false) {
                            synchronized (lock2) {
                                info.gameContinuing = false;
                                String temp = gson.toJson(info);
                                dos.write(temp + "\n");
                                dos.flush();
                                break;
                            }
                        } else {
                            dos.write(info_json + "\n");
                            dos.flush();
                        }

                        String game_out_json = dis.readLine();
                        InformationGamers.GamerOut game_out = gson.fromJson(game_out_json, InformationGamers.GamerOut.class);

                        if (game_out.arrow_shot_trigger == true && info.arrow_shots[thread_num] == false) {
                            info.arrow_shots[thread_num] = true;
                            info.arrow_counts[thread_num]++;
                        }

                        if (game_out.pause_trigger == true) {
                            synchronized (lock) {
                                if (threadPause == false) {
                                    threadPause = true;
                                } else {
                                    synchronized (hc) {
                                        hc.notifyAll();
                                        threadPause = false;
                                    }
                                }
                            }
                        }
                    }

                } catch (IOException | InterruptedException ex) {
                    ex.printStackTrace();
                } finally {
                    System.out.println("Client " + thread_num + " disconnected");
                    try {
                        if (dos != null) {
                            dos.close();
                        }
                        if (dis != null) {
                            dis.close();
                            cs.close();
                        }

                        if (thread_num == 0) {
                            new MulThrGameServer().StartServer();
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        }

        sendandreceive[thread_num] = new Thread(new SendReceive(this, cs, thread_num));
        sendandreceive[thread_num].start();
    }


    public void StartServer() {

        sendandreceive = new Thread[COUNT_GAMERS];
        auth = new Thread[COUNT_GAMERS];
        nicknames = new String[COUNT_GAMERS];
        gameContinuing = true;

        Session session = HibernateSessionFactoryUtil.getSessionFactory().openSession();
        Query query = session.createQuery("from Gamers");
        list = (List<Gamers>)query.list();
        session.close();

        System.out.append("Game server start!!!\n");
        try {
            ip = InetAddress.getLocalHost();
            ss = new ServerSocket(port, 0, ip);

            Socket[] cs_arr = new Socket[COUNT_GAMERS];

            for (int i = 0; i < COUNT_GAMERS; i++) {
                Socket cs = ss.accept();
                System.out.println("Client connect (" + cs.getPort() + ")");
                System.out.println("New client connected: " + i + "\n");
                Auth(cs, i);
                cs_arr[i] = cs;
            }
            System.out.println("All clients are connected!");
            for(int i = 0; i < COUNT_GAMERS; i++){
                auth[i].join();
            }
            System.out.println("Authentication is completed!");
            info.nicknames = nicknames;

            for(int i = 0; i < COUNT_GAMERS; i++){
                send_and_receive(cs_arr[i], i);
            }

            MainWork();

        } catch (IOException | InterruptedException ex) {
            System.out.println("Error");
        } finally {
            if (ss != null) {
                try {
                    ss.close();
                    System.out.println("Server is closed");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }


    public static void main(String[] args) {
        new MulThrGameServer().StartServer();
    }

}
